package fdi.ucm.musicot.Observers;

/**
 * Created by Javier on 01/06/2017.
 */

public interface OnKeyEventHandler {

    public abstract void keyPressed(int keyCode);

    public abstract void textModified();
}
