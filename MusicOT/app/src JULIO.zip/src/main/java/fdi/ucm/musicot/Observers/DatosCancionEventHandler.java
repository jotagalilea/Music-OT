package fdi.ucm.musicot.Observers;

/**
 * Created by Deekin on 01/06/2017.
 */

public interface DatosCancionEventHandler {

    public abstract void actualizaDatosCancion();

    public abstract void updatePlayButton();
}
