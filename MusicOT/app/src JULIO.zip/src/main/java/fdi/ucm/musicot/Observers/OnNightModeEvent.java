package fdi.ucm.musicot.Observers;

/**
 * Created by Javier on 03/06/2017.
 */

public interface OnNightModeEvent {

    public abstract void toNightMode();
    public abstract void toDayMode();
}
